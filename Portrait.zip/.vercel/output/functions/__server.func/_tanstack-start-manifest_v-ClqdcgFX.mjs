//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ClqdcgFX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CGmTWAKE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CGmTWAKE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BHI3pHGG.js"]
	}
} });
//#endregion
export { tsrStartManifest };
