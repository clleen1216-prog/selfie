import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as WARDS, o as promptFor, t as STEPS } from "./prompts-Jkxeab6K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/edit.functions-CSUPM-1V.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
var WINDOW_MS = 9e5;
var GLOBAL_MAX = 40;
var SESSION_MAX = 16;
var usage = {
	windowStart: Date.now(),
	count: 0,
	sessions: /* @__PURE__ */ new Map()
};
function slotState(sessionId) {
	const now = Date.now();
	if (now - usage.windowStart > WINDOW_MS) {
		usage.windowStart = now;
		usage.count = 0;
		usage.sessions.clear();
	}
	const used = usage.sessions.get(sessionId) ?? 0;
	if (used >= SESSION_MAX) return { error: "This sitting has used its portrait generations. Come back a little later for another." };
	if (usage.count >= GLOBAL_MAX) return { error: "The studio is resting. Try again in a little while." };
	return { used };
}
function commitSlot(sessionId) {
	const now = Date.now();
	if (now - usage.windowStart > WINDOW_MS) {
		usage.windowStart = now;
		usage.count = 0;
		usage.sessions.clear();
	}
	usage.sessions.set(sessionId, (usage.sessions.get(sessionId) ?? 0) + 1);
	usage.count += 1;
}
var MULTI_ANGLE = "The first image is the only photograph to change. Every later image is another angle of that same one person — front, three-quarter, or profile — and is an identity reference only. Output exactly one person. Do not collage the angles, do not duplicate the person, and do not invent a new face. Use the extra angles to lock bone structure, eye shape, nose, lips, jaw, and how the face turns in space.";
function imageHostAllowed(hostname) {
	return hostname === "imgen.x.ai" || hostname.endsWith(".x.ai") || hostname.endsWith(".grok.com");
}
function normalizeSource(source) {
	if (source.startsWith("https://")) {
		if (source.length > 2e3) return { error: "That image link isn’t valid." };
		let parsed;
		try {
			parsed = new URL(source);
		} catch {
			return { error: "That image link isn’t valid." };
		}
		if (!imageHostAllowed(parsed.hostname)) return { error: "Only a photograph from this sitting can be continued." };
		return { url: source };
	}
	if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=\s]+$/.test(source)) return { error: "Use a JPEG, PNG, or WebP photograph." };
	if (source.length > 7e5) return { error: "That photograph is too large. Try another, or a smaller crop." };
	return { url: source.replace(/\s/g, "") };
}
function apiMessage(body) {
	if (!body || typeof body !== "object") return "";
	const record = body;
	return [typeof record.code === "string" ? record.code : "", typeof record.error === "string" ? record.error : record.error && typeof record.error.message === "string" ? record.error.message : typeof record.message === "string" ? record.message : ""].filter(Boolean).join(" ");
}
function publicError(status, raw) {
	const clipped = raw.replace(/\s+/g, " ").slice(0, 240);
	if (/credit|spending-limit|spending limit|subscription|quota/i.test(clipped)) return "Portrait generation is paused — the studio’s image credits are used up. Add credits, then try again.";
	if (status === 401 || status === 403) return "The studio can’t reach the portrait model right now.";
	if (status === 429) return "The studio is busy. Wait a moment, then try this pass again.";
	if (/safety|policy|moderation|not allowed/i.test(clipped)) return "That photograph couldn’t be used for a portrait. Try another.";
	return "The portrait pass didn’t finish. Try this pass again.";
}
function imageFromBody(body) {
	const first = body.data?.[0];
	if (!first) return null;
	if (typeof first.url === "string" && first.url.startsWith("https://")) return first.url;
	if (typeof first.b64_json === "string" && first.b64_json.length > 32) return `data:${first.mime_type?.startsWith("image/") ? first.mime_type : "image/jpeg"};base64,${first.b64_json}`;
	return null;
}
async function postEdit(apiKey, payload) {
	const res = await fetch("https://api.x.ai/v1/images/edits", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(payload),
		signal: AbortSignal.timeout(85e3)
	});
	const text = await res.text();
	let body = null;
	try {
		body = JSON.parse(text);
	} catch {
		body = null;
	}
	return {
		status: res.status,
		body,
		text
	};
}
function isModelMiss(status, message) {
	return status === 404 || /model|not found|does not exist|unknown/i.test(message);
}
var studioReady_createServerFn_handler = createServerRpc({
	id: "cdf484ce42f7b8cadf81e6b699f823d1b37521fce5781dc4c72492e7edb0d64f",
	name: "studioReady",
	filename: "src/lib/portrait/edit.functions.ts"
}, (opts) => studioReady.__executeServer(opts));
var studioReady = createServerFn({ method: "GET" }).handler(studioReady_createServerFn_handler, async () => {
	return { ready: Boolean(process.env.XAI_API_KEY) };
});
var developPortrait_createServerFn_handler = createServerRpc({
	id: "baebd6d435a847fa49b95e507ab0016a490c9ef41f8c1478032371aab7202a4d",
	name: "developPortrait",
	filename: "src/lib/portrait/edit.functions.ts"
}, (opts) => developPortrait.__executeServer(opts));
var developPortrait = createServerFn({ method: "POST" }).validator((input) => input).handler(developPortrait_createServerFn_handler, async ({ data }) => {
	if (!UUID.test(data.sessionId)) return {
		ok: false,
		error: "That request didn’t look right."
	};
	if (!STEPS.includes(data.step) || !WARDS.includes(data.wardrobe)) return {
		ok: false,
		error: "That request didn’t look right."
	};
	if (typeof data.keepClothes !== "boolean" || !Array.isArray(data.sources)) return {
		ok: false,
		error: "That request didn’t look right."
	};
	if (data.sources.length < 1 || data.sources.length > 4) return {
		ok: false,
		error: "That request didn’t look right."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Portrait generation isn’t available right now."
	};
	const urls = [];
	for (const item of data.sources) {
		if (typeof item !== "string") return {
			ok: false,
			error: "That request didn’t look right."
		};
		const source = normalizeSource(item);
		if ("error" in source) return {
			ok: false,
			error: source.error
		};
		urls.push(source.url);
	}
	const slot = slotState(data.sessionId);
	if ("error" in slot) return {
		ok: false,
		error: slot.error
	};
	const prompt = [urls.length > 1 ? MULTI_ANGLE : "", promptFor(data.step, data.wardrobe, data.keepClothes)].filter(Boolean).join(" ");
	const wantsAspect = data.step === "sitting" || data.step === "finish" || data.step === "polish";
	let resolution = data.step === "print" || data.step === "sitting" || data.step === "polish" || data.step === "finish" ? "2k" : "1k";
	let model = "grok-imagine-image-2.0";
	let aspect = wantsAspect;
	let useAllAngles = urls.length > 1;
	let attemptedModelFallback = false;
	let attemptedShapeFallback = false;
	let attemptedRetry = false;
	for (let attempt = 0; attempt < 3; attempt++) {
		const payload = {
			model,
			prompt,
			response_format: "url",
			n: 1,
			resolution
		};
		if (useAllAngles) payload.images = urls.map((url) => ({
			url,
			type: "image_url"
		}));
		else payload.image = {
			url: urls[0],
			type: "image_url"
		};
		if (aspect) payload.aspect_ratio = "2:3";
		let status = 0;
		let body = null;
		try {
			const posted = await postEdit(apiKey, payload);
			status = posted.status;
			body = posted.body;
		} catch {
			if (!attemptedRetry) {
				attemptedRetry = true;
				await new Promise((resolve) => setTimeout(resolve, 1200));
				continue;
			}
			return {
				ok: false,
				error: "That pass took too long. Try it again."
			};
		}
		if (status >= 200 && status < 300) {
			const url = imageFromBody(body ?? {});
			if (!url) return {
				ok: false,
				error: "The portrait came back empty. Try this pass again."
			};
			commitSlot(data.sessionId);
			return {
				ok: true,
				url
			};
		}
		const message = apiMessage(body);
		if (!attemptedModelFallback && isModelMiss(status, message)) {
			attemptedModelFallback = true;
			model = "grok-imagine-image";
			continue;
		}
		if (!attemptedShapeFallback && status === 400 && (aspect || resolution === "2k" || useAllAngles)) {
			attemptedShapeFallback = true;
			if (useAllAngles) useAllAngles = false;
			else if (resolution === "2k") resolution = "1k";
			else aspect = false;
			continue;
		}
		if (!attemptedRetry && (status === 429 || status >= 500)) {
			attemptedRetry = true;
			await new Promise((resolve) => setTimeout(resolve, 1200));
			continue;
		}
		return {
			ok: false,
			error: publicError(status, message)
		};
	}
	return {
		ok: false,
		error: "The portrait pass didn’t finish. Try this pass again."
	};
});
var fetchPortrait_createServerFn_handler = createServerRpc({
	id: "164608e2ad68f7483bb97ce9df45b8ea989cb999de3b811be6197c0b623a6933",
	name: "fetchPortrait",
	filename: "src/lib/portrait/edit.functions.ts"
}, (opts) => fetchPortrait.__executeServer(opts));
var fetchPortrait = createServerFn({ method: "POST" }).validator((input) => input).handler(fetchPortrait_createServerFn_handler, async ({ data }) => {
	if (typeof data.url !== "string" || !data.url.startsWith("https://") || data.url.length > 2e3) return {
		ok: false,
		error: "That portrait can’t be saved from here."
	};
	let parsed;
	try {
		parsed = new URL(data.url);
	} catch {
		return {
			ok: false,
			error: "That portrait can’t be saved from here."
		};
	}
	if (!imageHostAllowed(parsed.hostname)) return {
		ok: false,
		error: "That portrait can’t be saved from here."
	};
	try {
		const res = await fetch(data.url, { signal: AbortSignal.timeout(2e4) });
		if (!res.ok) return {
			ok: false,
			error: "The portrait file wasn’t ready. Open it instead."
		};
		const mime = res.headers.get("content-type") ?? "image/jpeg";
		if (!mime.startsWith("image/")) return {
			ok: false,
			error: "The portrait file wasn’t ready. Open it instead."
		};
		const bytes = new Uint8Array(await res.arrayBuffer());
		if (bytes.byteLength < 32 || bytes.byteLength > 8e6) return {
			ok: false,
			error: "The portrait file wasn’t ready. Open it instead."
		};
		let binary = "";
		const chunk = 32768;
		for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
		return {
			ok: true,
			base64: btoa(binary),
			mime
		};
	} catch {
		return {
			ok: false,
			error: "The portrait file wasn’t ready. Open it instead."
		};
	}
});
//#endregion
export { developPortrait_createServerFn_handler, fetchPortrait_createServerFn_handler, studioReady_createServerFn_handler };
