import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as planFor, i as WARDS, n as STEP_COPY, r as WARDROBE_LABEL } from "./prompts-Jkxeab6K.mjs";
import { a as ImagePlus, i as RotateCcw, o as Download, r as Square, s as Aperture, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-dA4dRsqJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var studioReady = createServerFn({ method: "GET" }).handler(createSsrRpc("cdf484ce42f7b8cadf81e6b699f823d1b37521fce5781dc4c72492e7edb0d64f"));
var developPortrait = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("baebd6d435a847fa49b95e507ab0016a490c9ef41f8c1478032371aab7202a4d"));
var fetchPortrait = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("164608e2ad68f7483bb97ce9df45b8ea989cb999de3b811be6197c0b623a6933"));
var SESSION_KEY = "halide-session";
function useSessionId() {
	const [id, setId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let existing = sessionStorage.getItem(SESSION_KEY);
		if (!existing) {
			existing = crypto.randomUUID();
			sessionStorage.setItem(SESSION_KEY, existing);
		}
		setId(existing);
	}, []);
	return id;
}
async function fileToJpeg(file) {
	if (!file.type.startsWith("image/")) throw new Error("Choose a photograph — JPEG, PNG, or WebP.");
	const bitmap = await createImageBitmap(file).catch(() => {
		throw new Error("This browser couldn’t read that photograph. Try a JPEG or PNG.");
	});
	let edge = 1280;
	let quality = .86;
	const draw = (maxEdge, q) => {
		const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Couldn’t read that photograph.");
		ctx.drawImage(bitmap, 0, 0, width, height);
		return canvas.toDataURL("image/jpeg", q);
	};
	let url = draw(edge, quality);
	while (url.length > 68e4 && (quality > .5 || edge > 720)) {
		if (quality > .5) quality -= .08;
		else edge = Math.round(edge * .85);
		url = draw(edge, quality);
	}
	bitmap.close();
	if (url.length > 69e4) throw new Error("That photograph is still too large. Try a smaller one.");
	return url;
}
async function savePortrait(url, filename) {
	if (url.startsWith("data:")) {
		const anchor = document.createElement("a");
		anchor.href = url;
		anchor.download = filename;
		anchor.click();
		return;
	}
	const fetched = await fetchPortrait({ data: { url } });
	if (!fetched.ok) {
		window.open(url, "_blank", "noopener,noreferrer");
		return;
	}
	const binary = atob(fetched.base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	const blob = new Blob([bytes], { type: fetched.mime });
	const objectUrl = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = objectUrl;
	anchor.download = filename;
	anchor.click();
	URL.revokeObjectURL(objectUrl);
}
function Studio() {
	const sessionId = useSessionId();
	const inputId = (0, import_react.useId)();
	const fileRef = (0, import_react.useRef)(null);
	const cancelRef = (0, import_react.useRef)(false);
	const runLock = (0, import_react.useRef)(false);
	const [ready, setReady] = (0, import_react.useState)(null);
	const [original, setOriginal] = (0, import_react.useState)(null);
	const [angles, setAngles] = (0, import_react.useState)([]);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const [wardrobe, setWardrobe] = (0, import_react.useState)("charcoal");
	const [keepClothes, setKeepClothes] = (0, import_react.useState)(false);
	const [mode, setMode] = (0, import_react.useState)("careful");
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [frames, setFrames] = (0, import_react.useState)([]);
	const [active, setActive] = (0, import_react.useState)(0);
	const [stepIndex, setStepIndex] = (0, import_react.useState)(0);
	const [lockedPlan, setLockedPlan] = (0, import_react.useState)(null);
	const [compare, setCompare] = (0, import_react.useState)(false);
	const [seam, setSeam] = (0, import_react.useState)(58);
	const [printing, setPrinting] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [resume, setResume] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		studioReady().then((result) => {
			if (!cancelled) setReady(result.ready);
		}).catch(() => {
			if (!cancelled) setReady(false);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	async function takeFile(file) {
		if (!file) return;
		setError(null);
		setNotice(null);
		try {
			const jpeg = await fileToJpeg(file);
			setOriginal(jpeg);
			setFileName(file.name);
			setAngles([]);
			setFrames([]);
			setActive(0);
			setPhase("idle");
			setResume(null);
			setLockedPlan(null);
			setCompare(false);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Couldn’t read that photograph.");
		}
	}
	async function runFrom(startSource, startIndex, plan) {
		if (!sessionId || !original || runLock.current) return;
		runLock.current = true;
		cancelRef.current = false;
		setError(null);
		setNotice(null);
		setCompare(false);
		setPrinting(false);
		let source = startSource;
		const nextFrames = frames.slice(0, startIndex);
		let cursor = startIndex;
		setFrames(nextFrames);
		setPhase("running");
		try {
			for (let i = startIndex; i < plan.length; i++) {
				cursor = i;
				setStepIndex(i);
				const step = plan[i];
				const result = await developPortrait({ data: {
					sessionId,
					step,
					sources: [source, ...angles].slice(0, 4),
					wardrobe,
					keepClothes
				} });
				if (cancelRef.current) {
					if (result.ok) {
						const kept = [...nextFrames, {
							step,
							url: result.url
						}];
						setFrames(kept);
						setActive(kept.length - 1);
					}
					setPhase("held");
					setNotice("Held on the last finished pass. Continue from it, or stop here.");
					return;
				}
				if (!result.ok) {
					setFrames([...nextFrames]);
					setResume({
						source,
						index: i
					});
					setError(result.error);
					setPhase("error");
					return;
				}
				source = result.url;
				nextFrames.push({
					step,
					url: result.url
				});
				setFrames([...nextFrames]);
				setActive(nextFrames.length - 1);
			}
			setResume(null);
			setPhase("done");
		} catch {
			setResume({
				source,
				index: cursor
			});
			setError("The portrait pass didn’t finish. Try this pass again.");
			setPhase("error");
		} finally {
			runLock.current = false;
		}
	}
	function develop() {
		if (!original) return;
		const plan = planFor(mode, keepClothes);
		setLockedPlan(plan);
		runFrom(original, 0, plan);
	}
	function retry() {
		const plan = lockedPlan ?? planFor(mode, keepClothes);
		if (!resume || !original) {
			develop();
			return;
		}
		runFrom(resume.source, resume.index, plan);
	}
	function continueHere() {
		if (!lockedPlan) return;
		const frame = frames[active];
		if (!frame) return;
		const planIndex = lockedPlan.indexOf(frame.step);
		if (planIndex < 0 || planIndex >= lockedPlan.length - 1) return;
		setNotice(null);
		runFrom(frame.url, planIndex + 1, lockedPlan);
	}
	function stop() {
		cancelRef.current = true;
		setNotice("Finishing this pass, then holding.");
	}
	async function printRefine() {
		if (!sessionId || runLock.current) return;
		const current = frames[active] ?? frames[frames.length - 1];
		if (!current) return;
		runLock.current = true;
		cancelRef.current = false;
		setError(null);
		setNotice(null);
		setPhase("running");
		setPrinting(true);
		setCompare(false);
		try {
			const result = await developPortrait({ data: {
				sessionId,
				step: "print",
				sources: [current.url, ...angles].slice(0, 4),
				wardrobe,
				keepClothes
			} });
			if (!result.ok) {
				setError(result.error);
				setPhase(frames.length ? "done" : "error");
				return;
			}
			const next = [...frames, {
				step: "print",
				url: result.url
			}];
			setFrames(next);
			setActive(next.length - 1);
			setPhase("done");
		} catch {
			setError("The print refine didn’t finish. Try it again.");
			setPhase("done");
		} finally {
			setPrinting(false);
			runLock.current = false;
		}
	}
	async function onSave(filename) {
		const current = frames[active];
		if (!current) return;
		setSaving(true);
		try {
			await savePortrait(current.url, filename);
		} finally {
			setSaving(false);
		}
	}
	const running = phase === "running";
	const viewed = frames[active] ?? null;
	const prospective = planFor(mode, keepClothes);
	const planSteps = phase === "idle" && frames.length === 0 ? prospective : lockedPlan ?? prospective;
	const activeStep = printing ? "print" : running ? planSteps[stepIndex] ?? null : viewed?.step ?? null;
	const canPrint = !running && frames.some((frame) => frame.step === "finish" || frame.step === "sitting" || frame.step === "polish");
	const planIndex = viewed && lockedPlan ? lockedPlan.indexOf(viewed.step) : -1;
	const canContinue = !running && lockedPlan !== null && planIndex >= 0 && planIndex < lockedPlan.length - 1;
	const canWipe = Boolean(compare && original && viewed);
	const lastStep = lockedPlan?.[lockedPlan.length - 1] ?? null;
	const finished = !running && viewed !== null && (viewed.step === "print" || lastStep !== null && viewed.step === lastStep && (phase === "done" || phase === "held"));
	const sheetComplete = !running && lockedPlan !== null && lockedPlan.every((step) => frames.some((frame) => frame.step === step));
	const doneCount = frames.filter((frame) => planSteps.includes(frame.step)).length;
	const progress = planSteps.length ? Math.round(Math.min(doneCount, planSteps.length) / planSteps.length * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bone text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto flex max-w-6xl items-end justify-between gap-6 px-5 pt-7 pb-5 md:px-8 md:pt-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 place-items-center rounded-full bg-ink text-paper shadow-mat",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aperture, {
						className: "size-5",
						strokeWidth: 1.75,
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Portrait studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl leading-none font-medium tracking-tight md:text-5xl",
					children: "Halide"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden max-w-xs text-right text-sm leading-relaxed text-muted md:block",
				children: "A studio portrait from the photograph you already have. The face stays yours."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto grid max-w-6xl items-start gap-6 px-5 pb-16 md:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] md:gap-8 md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: `flex flex-col gap-5 ${viewed || running ? "order-2 md:order-1" : "order-1"}`,
				"aria-label": "Photograph and sitting",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-2xl bg-paper p-3 shadow-mat ${dragOver ? "ring-2 ring-umber" : ""}`,
						onDragOver: (event) => {
							event.preventDefault();
							setDragOver(true);
						},
						onDragLeave: () => setDragOver(false),
						onDrop: (event) => {
							event.preventDefault();
							setDragOver(false);
							if (running) return;
							takeFile(event.dataTransfer.files[0]);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-xl bg-bone",
							children: original ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: original,
								alt: fileName ? `Your photograph, ${fileName}` : "Your photograph",
								className: "frame-angle w-full bg-bone object-contain outline -outline-offset-1 outline-ink/10"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "frame-angle flex flex-col items-center justify-center gap-3 px-6 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
										className: "size-6 text-umber",
										strokeWidth: 1.5,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl text-ink",
										children: "Place a photograph"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-xs text-sm leading-relaxed text-muted",
										children: "A selfie is enough. Face the lens, even light if you have it. Drag it here or choose a file."
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: inputId,
								ref: fileRef,
								type: "file",
								accept: "image/jpeg,image/png,image/webp,image/*",
								className: "sr-only",
								suppressHydrationWarning: true,
								onChange: (event) => {
									takeFile(event.target.files?.[0]);
									event.target.value = "";
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: inputId,
								className: "inline-flex min-h-11 items-center rounded-full bg-ink px-4 text-sm font-medium text-paper",
								children: original ? "Replace photograph" : "Choose photograph"
							}),
							fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "self-center truncate text-sm text-muted",
								children: fileName
							}) : null
						]
					}),
					original ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "More angles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: "Optional. Up to three other views of the same person, used only to lock the face."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [angles.map((angle, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: running,
								onClick: () => setAngles((current) => current.filter((_, i) => i !== index)),
								className: "relative size-16 overflow-hidden rounded-xl shadow-mat",
								"aria-label": `Remove angle ${index + 1}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: angle,
									alt: "",
									className: "size-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-1 right-1 grid size-5 place-items-center rounded-full bg-ink text-paper",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
										className: "size-3",
										"aria-hidden": "true"
									})
								})]
							}, `angle-${index}`)), angles.length < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid size-16 cursor-pointer place-items-center rounded-xl bg-paper text-xs font-medium text-ink shadow-mat",
								children: ["Add", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/jpeg,image/png,image/webp,image/*",
									className: "sr-only",
									suppressHydrationWarning: true,
									disabled: running,
									onChange: (event) => {
										const file = event.target.files?.[0];
										event.target.value = "";
										if (!file) return;
										fileToJpeg(file).then((jpeg) => {
											setAngles((current) => current.length >= 3 ? current : [...current, jpeg]);
											setError(null);
										}).catch((err) => {
											setError(err instanceof Error ? err.message : "Couldn’t read that photograph.");
										});
									}
								})]
							}) : null]
						})
					] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "m-0 flex flex-col gap-3 border-0 p-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-xs font-medium tracking-widest text-muted uppercase",
								children: "Wardrobe"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
								children: WARDS.map((color) => {
									const selected = wardrobe === color;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": selected,
										disabled: running,
										onClick: () => setWardrobe(color),
										className: `inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-3 text-sm font-medium ${selected ? "bg-ink text-paper" : "bg-paper text-ink shadow-mat"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `size-3 shrink-0 rounded-full ${color === "black" ? "bg-cloth-black" : color === "charcoal" ? "bg-cloth-charcoal" : color === "cream" ? "bg-cloth-cream" : "bg-cloth-taupe"} ${selected ? "ring-2 ring-paper" : "ring-1 ring-ink/15"}`,
											"aria-hidden": "true"
										}), WARDROBE_LABEL[color]]
									}, color);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": keepClothes,
								disabled: running,
								onClick: () => setKeepClothes((value) => !value),
								className: `min-h-11 rounded-full px-4 text-left text-sm ${keepClothes ? "bg-ink text-paper" : "bg-paper text-ink shadow-mat"}`,
								children: keepClothes ? "Keeping the clothes in the photo" : "Keep the clothes in the photo"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "m-0 border-0 p-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "How to develop"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-3 gap-2",
							children: [
								["careful", "Sequence"],
								["session", "Session"],
								["sitting", "Sitting"]
							].map(([id, label]) => {
								const selected = mode === id;
								const count = planFor(id, keepClothes).length;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": selected,
									disabled: running,
									onClick: () => setMode(id),
									className: `min-h-11 rounded-full px-2 text-sm font-medium ${selected ? "bg-ink text-paper" : "bg-paper text-ink shadow-mat"}`,
									children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `ml-1 tabular-nums ${selected ? "text-paper/70" : "text-muted"}`,
										children: count
									})]
								}, id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: stop,
								className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-ink px-5 text-sm font-medium text-paper",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
									className: "size-3.5 fill-current",
									"aria-hidden": "true"
								}), "Hold"]
							}) : phase === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: retry,
									disabled: !original || !sessionId || ready === false,
									className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-umber px-5 text-sm font-medium text-paper disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Try this pass again"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: develop,
									disabled: !original || !sessionId || ready === false,
									className: "inline-flex min-h-11 items-center justify-center rounded-full bg-paper px-4 text-sm font-medium text-ink shadow-mat disabled:opacity-40",
									children: "Start over"
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: develop,
								disabled: !original || !sessionId || ready === false,
								className: "inline-flex min-h-12 items-center justify-center rounded-full bg-umber px-5 text-sm font-medium text-paper disabled:opacity-40",
								children: [frames.length ? "Develop again" : "Develop portrait", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 tabular-nums text-paper/70",
									children: prospective.length
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: [
									phase === "done" && frames.length ? "This sitting is finished. Save the portrait, or develop again if you want another." : mode === "careful" ? keepClothes ? "Sequence keeps the clothes and changes one thing at a time. Hold if a pass stops looking like you." : "Sequence changes one thing at a time: clean, backdrop, light, retouch, makeup, hair, clothes, pose, then polish. Hold if a pass stops looking like you." : mode === "session" ? "Session is four generations: clean, backdrop, light, then a quiet finish. Hold after any pass." : "Sitting is one generation: backdrop, light, and finish together.",
									" ",
									phase === "done" && frames.length ? "The face is not reshaped." : "Nothing here reshapes, slims, or beautifies the face."
								]
							}),
							ready === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-umber-deep",
								role: "status",
								children: "Portrait generation isn’t available in this environment yet."
							}) : null
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: `flex flex-col gap-4 ${viewed || running ? "order-1 md:order-2" : "order-2"}`,
				"aria-label": "Portrait",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-ink p-3 text-paper shadow-mat md:p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-baseline justify-between gap-3 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-paper/60 uppercase",
									children: finished ? "Your portrait" : activeStep ? STEP_COPY[activeStep].title : "Proof"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-paper/50 tabular-nums",
									children: running ? printing ? "Refining" : planSteps.length === 1 ? "Developing" : `${String(Math.min(stepIndex + 1, planSteps.length)).padStart(2, "0")} / ${String(planSteps.length).padStart(2, "0")}` : finished ? "Finished" : viewed ? canWipe ? "Compare" : "Ready" : "Waiting"
								})]
							}),
							(phase !== "idle" || frames.length > 0) && planSteps.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 h-1 overflow-hidden rounded-full bg-paper/15",
								role: "progressbar",
								"aria-valuemin": 0,
								"aria-valuemax": planSteps.length,
								"aria-valuenow": Math.min(doneCount, planSteps.length),
								"aria-label": "Passes finished",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-umber",
									style: { width: `${progress}%` }
								})
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-xl bg-ink",
								children: [
									canWipe && original && viewed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: original,
											alt: "Your original photograph",
											className: "frame-proof w-full object-cover"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: viewed.url,
											alt: `${STEP_COPY[viewed.step].title} portrait`,
											className: "frame-proof absolute inset-0 w-full object-cover",
											style: { clipPath: `inset(0 0 0 ${seam}%)` }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pointer-events-none absolute inset-y-0 w-0.5 bg-paper",
											style: { left: `${seam}%` }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "pointer-events-none absolute top-3 left-3 rounded-full bg-ink/80 px-2.5 py-1 text-xs text-paper",
											children: "Before"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "pointer-events-none absolute top-3 right-3 rounded-full bg-ink/80 px-2.5 py-1 text-xs text-paper",
											children: "After"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "absolute inset-x-3 bottom-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sr-only",
												children: "Compare seam"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "range",
												min: 0,
												max: 100,
												value: seam,
												onChange: (event) => setSeam(Number(event.target.value)),
												className: "compare-range"
											})]
										})
									] }) : viewed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: viewed.url,
										alt: `${STEP_COPY[viewed.step].title} portrait`,
										className: "frame-proof w-full object-cover outline -outline-offset-1 outline-paper/15"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "frame-proof flex flex-col justify-between p-6 md:p-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-widest text-paper/50 uppercase",
											children: "Head and shoulders"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-4xl leading-tight font-medium text-paper md:text-5xl",
											children: "The portrait sits here."
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 max-w-sm text-sm leading-relaxed text-paper/65",
											children: "Warm pale-bone ground, soft light, a plain top. You’ll see each pass as it finishes."
										})] })]
									}),
									running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "developing-veil pointer-events-none absolute inset-0 bg-bone" }) : null,
									running && activeStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pointer-events-none absolute inset-x-0 bottom-0 bg-ink/80 px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-paper",
											children: STEP_COPY[activeStep].title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-paper/75",
											children: STEP_COPY[activeStep].detail
										})]
									}) : null
								]
							})
						]
					}),
					planSteps.length > 1 && !sheetComplete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "flex flex-wrap gap-2",
						children: planSteps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepMark, {
							step,
							index,
							state: stepState(step, index, frames, running && !printing, stepIndex, phase)
						}, `${step}-${index}`))
					}) : null,
					frames.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: frames.map((frame, index) => {
							const selected = index === active && !canWipe;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setCompare(false);
									setActive(index);
								},
								"aria-pressed": selected,
								className: `flex shrink-0 flex-col items-center gap-1 rounded-xl p-1 ${selected ? "bg-umber text-paper" : "bg-paper text-ink shadow-mat"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: frame.url,
									alt: "",
									className: "thumb rounded-lg object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-1 pb-1 text-xs font-medium",
									children: STEP_COPY[frame.step].short
								})]
							}, `${frame.step}-${index}`);
						})
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-2xl bg-paper px-4 py-3 text-sm text-umber-deep shadow-mat",
						role: "alert",
						children: error
					}) : null,
					notice && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						role: "status",
						children: notice
					}) : null,
					viewed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void onSave(finished ? "halide-portrait.jpg" : `halide-${viewed.step}.jpg`),
								disabled: saving || running,
								className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm font-medium text-paper disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}), saving ? "Saving…" : finished ? "Save portrait" : "Save this pass"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": compare,
								onClick: () => {
									setCompare((value) => !value);
									setSeam(58);
								},
								disabled: running || !original,
								className: `inline-flex min-h-11 items-center rounded-full px-4 text-sm font-medium disabled:opacity-40 ${compare ? "bg-umber text-paper" : "bg-paper text-ink shadow-mat"}`,
								children: compare ? "Close compare" : "Compare"
							}),
							canContinue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: continueHere,
								disabled: !sessionId || ready === false,
								className: "inline-flex min-h-11 items-center rounded-full bg-paper px-4 text-sm font-medium text-ink shadow-mat disabled:opacity-40",
								children: "Continue from here"
							}) : null,
							canPrint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void printRefine(),
								disabled: running || !sessionId,
								className: "inline-flex min-h-11 items-center rounded-full bg-paper px-4 text-sm font-medium text-ink shadow-mat disabled:opacity-40",
								children: "Refine for print"
							}) : null
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: finished ? "Your photograph was used only to make this portrait. It isn’t saved on a server. Earlier passes stay in the strip if a later one drifted." : "Your photograph is used only to make this portrait. It isn’t saved on a server. If a pass stops looking like you, hold and continue from the last good frame."
					})
				]
			})]
		})]
	});
}
function StepMark({ step, index, state }) {
	const copy = STEP_COPY[step];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: `inline-flex min-h-11 items-center gap-2 rounded-full px-3 text-sm ${state === "now" ? "bg-umber text-paper" : "bg-paper text-ink shadow-mat"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `tabular-nums ${state === "now" ? "text-paper/80" : "text-muted"}`,
			children: String(index + 1).padStart(2, "0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: copy.short
		})]
	});
}
function stepState(step, index, frames, running, stepIndex, phase) {
	if (frames.some((frame) => frame.step === step)) return "done";
	if (running && stepIndex === index) return "now";
	if (phase === "error" && stepIndex === index) return "now";
	return "wait";
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
